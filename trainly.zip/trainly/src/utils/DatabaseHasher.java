package utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.trainly.BCrypt;

public class DatabaseHasher {
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager
					.getConnection("jdbc:mysql://localhost:3307/TRAINLY", "root", "");
			String sql1 = "SELECT UserId, Password FROM User;";
			final Statement stmt = con.createStatement();
			final ResultSet rs = stmt.executeQuery(sql1);
			while (rs.next()) {
				int userid = rs.getInt("UserId");
				System.out.println("user id is " + userid);
				String oldPass = rs.getString("Password");
				System.out.println("old password is " + oldPass);
				String salt = BCrypt.gensalt(12);
				System.out.println("salt is " + salt);
				String hashedPass = BCrypt.hashpw(oldPass, salt);
				System.out.println("hashed password is " + hashedPass);
				String sql2 = "UPDATE User SET Password=?, Salt=? WHERE UserId=?;";
				final PreparedStatement stmt2 = con.prepareStatement(sql2);
				stmt2.setString(1,  hashedPass);
				stmt2.setString(2,  salt);
				stmt2.setInt(3,  userid);
				stmt2.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.printf("Error connecting to db: %s%n", e.getMessage());
			System.exit(0);
		}
	}
}
