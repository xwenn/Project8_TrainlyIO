package controller.trainly;

import static org.apache.commons.lang3.text.WordUtils.wrap;

import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import model.trainly.BCrypt;
import org.apache.commons.validator.routines.EmailValidator;
import view.trainly.View;


public class TrainlyIO {

  private final static int FIXED_WIDTH = 50;
  private static View view;
  private final Readable in;
  private final Appendable out;

  private TrainlyIO(Readable in, Appendable out) {
    this.in = in;
    this.out = out;
    view = new View(out);
  }

  /**
   * Command-line Trainly.io utility
   *
   * @param args command-line arguments
   * @throws ClassNotFoundException cannot find JDBC driver
   * @throws SQLException SQL gone bad
   */
  public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
    TrainlyIO trainly = new TrainlyIO(new InputStreamReader(System.in), System.out);
    Scanner scan = new Scanner(trainly.in);
    view.printMainMenu();
    view.show("Enter an option: ");
    String option = scan.nextLine();
    try {
      Class.forName("com.mysql.jdbc.Driver");
      Connection con = DriverManager
          .getConnection("jdbc:mysql://localhost:3307/TRAINLY", "root", "");

      while (!option.equalsIgnoreCase("q")) {
        if ((!(option.equals("1"))) && (!(option.equals("2"))) && (!(option.equals("3")))
            && (!(option.equals("4"))) && (!(option.equalsIgnoreCase("p")))
            && (!(option.equalsIgnoreCase("q")))) {
          view.show("*************************************************\n"
              + "'" + option + "'" + " is not a valid menu option, please try again:\n"
              + "*************************************************");
        }
        if (option.equals("1")) {
          option = runStuMenu(con, scan);
        } else if (option.equals("2")) {
          option = runFacMenu(con, scan);
        } else if (option.equals("3")) {
          option = runAdminMenu(con, scan);
        } else if (option.equals("4")) {
          option = registerUser(con, scan);
        }
        if (option.equalsIgnoreCase("p")) {
          view.printMainMenu();
          view.show("Enter an option: ");
          option = scan.nextLine();
          continue;
        }
        if (option.equalsIgnoreCase("q")) {
          break;
        }
        view.printMainMenu();
        view.show("Enter an option: ");
        option = scan.nextLine();
      }
      view.quitProgram();
      con.close();
    } catch (SQLException e) {
      System.out.printf("Error connecting to db: %s%n", e.getMessage());
      System.exit(0);
    }
  }


  /**
   * Register a new user into the database
   *
   * @param con current database connection
   * @param scan scanner of user input
   * @return a string that represents uesr's next option
   * @throws IOException when IO exceptions occurs
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static String registerUser(Connection con, Scanner scan) throws IOException,
      ClassNotFoundException, SQLException {
    final String sql =
        "INSERT INTO User (Email, FirstName, LastName, Password, Salt, Phone, ProfilePic, Street, City, PostalCode, Country) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    view.show("Enter your email:");
    String email = scan.nextLine();

    view.show("Enter your first name:");
    String first = scan.nextLine();

    view.show("Enter your last name:");
    String last = scan.nextLine();

    view.show("Enter your password:");
    String pass = scan.nextLine();
    // salt, hash password
    String salt = BCrypt.gensalt(12);
    pass = BCrypt.hashpw(pass, salt);

    view.show("Enter your phone number:");
    String phone = scan.nextLine();

    view.show("Enter a link to your profile picture:");
    String picture = scan.nextLine();

    view.show("Enter your street:");
    String address = scan.nextLine();

    view.show("Enter your city:");
    String city = scan.nextLine();

    view.show("Enter your postal code:");
    String zip = scan.nextLine();

    view.show("Enter your country:");
    String country = scan.nextLine();

    // Insert data into User table
    final PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setString(1, email);
    stmt.setString(2, first);
    stmt.setString(3, last);
    stmt.setString(4, pass);
    stmt.setString(5, salt);
    stmt.setString(6, phone);
    stmt.setString(7, picture);
    stmt.setString(8, address);
    stmt.setString(9, city);
    stmt.setString(10, zip);
    stmt.setString(11, country);
    stmt.executeUpdate();

    // Insert data into Student table
    final String sql2 = "INSERT INTO Student(UserId) VALUES (LAST_INSERT_ID());";
    final PreparedStatement stmt2 = con.prepareStatement(sql2);
    stmt2.executeUpdate();

    // Get the user id that is automatically generated by database
    final String sql3 = "SELECT UserId FROM User WHERE Email=? AND FirstName=? AND LastName=?";
    final PreparedStatement stmt3 = con.prepareStatement(sql3);
    stmt3.setString(1, email);
    stmt3.setString(2, first);
    stmt3.setString(3, last);
    final ResultSet rs3 = stmt3.executeQuery();
    rs3.next();
    final int userid = rs3.getInt("UserId");
    view.show("Your user ID is " + userid);

    // Get the student id that is automatically generated by database
    final String sql4 = "SELECT StuId FROM Student WHERE UserId=?";
    final PreparedStatement stmt4 = con.prepareStatement(sql4);
    stmt4.setInt(1, userid);
    final ResultSet rs4 = stmt4.executeQuery();
    rs4.next();
    final int stuid = rs4.getInt("StuId");
    view.show("Your student ID is " + stuid);

    view.printMainMenu();
    view.show("Enter an option: ");
    return scan.nextLine();
  }

  /**
   * Implement of the Administrator menu
   *
   * @param con current database connection
   * @param scan scanner of user input
   * @return a string that represents uesr's next option
   * @throws IOException when IO exceptions occurs
   * @throws SQLException when exception occurs when trying to run sql queryeturn
   */
  private static String runAdminMenu(Connection con, Scanner scan) throws IOException,
      ClassNotFoundException, SQLException {
    // ask the user to enter administrator id
    view.show("Enter your Administrator ID: ");
    int adminid = 0;
    // return to prev menu if not enter an integer
    try {
      adminid = Integer.parseInt(scan.nextLine());
    } catch (NumberFormatException e) {
      view.show("Administrator ID should be a number.");
      return "p";
    }
    // return to prev menu if admin id is not in the database
    if (!isValidAdminId(con, adminid)) {
      view.show("Invalid Administrator ID.");
      return "p";
    }
    view.printAdminMenu();
    view.show("Enter your option:");
    String option = scan.nextLine();

    while (!option.equalsIgnoreCase("p") && !option.equalsIgnoreCase("q")) {
      try {
        if ((!(option.equals("1"))) && (!(option.equals("2"))) && (!(option.equals("3")))
            && (!(option.equals("4"))) && (!(option.equalsIgnoreCase("p")))
            && (!(option.equalsIgnoreCase("q")))) {
          view.show("*************************************************\n"
              + "'" + option + "'" + " is not a valid menu option, please try again:\n"
              + "*************************************************");
        }
        if (option.equals("1")) {
          // Enter '1' -- to authenticate a faculty user
          final String sql = authenticateFacultyUser();
          view.show("Enter faculty ID: ");
          int facid = 0;
          // show admin menu again if not enter an integer
          try {
            facid = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Faculty ID should be a number.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // show admin menu again if fac id is not valid
          if (!isValidFacId(con, facid)) {
            view.show("Faculty ID is not valid.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // show admin menu again if the fac has been verified
          if (isVerifiedFac(con, facid)) {
            view.show("This faculty has been verified.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          view.show("Enter date in yyyy-mm-dd format:");
          final String date = scan.nextLine();
          view.show("Enter time in hh:mm:ss format:");
          final String time = scan.nextLine();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, adminid);
          stmt.setString(2, date);
          stmt.setString(3, time);
          stmt.setInt(4, facid);
          int num = stmt.executeUpdate();
          if (num == 1) {
            view.show("Faculty " + facid + " has been successfully verified!");
          } else {
            view.show("Faculty verification of  " + facid + " failed");
          }
        } else if (option.equals("2")) {
          // Enter '2' -- to authenticate a fellow administrator
          final String sql = authenticateFellowAdmin();
          view.show("Enter administrator ID: ");
          int admin2 = 0;
          // show admin menu again if not enter an integer
          try {
            admin2 = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Administrator ID should be a number.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // show admin menu again if admin id is not valid
          if (!isValidAdminId(con, admin2)) {
            view.show("Administrator ID is not valid.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // show admin menu again if the admin has been granted
          if (isVerifiedAdmin(con, admin2)) {
            view.show("This administrator has been authenticated.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          view.show("Enter date in yyyy-mm-dd format:");
          final String date = scan.nextLine();
          view.show("Enter time in hh:mm:ss format:");
          final String time = scan.nextLine();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, adminid);
          stmt.setString(2, date);
          stmt.setString(3, time);
          stmt.setInt(4, admin2);
          int num = stmt.executeUpdate();
          if (num == 1) {
            view.show("Administrator " + admin2 + " has been successfully verified!");
          } else {
            view.show("Verification of  " + admin2 + " failed.");
          }
        } else if (option.equals("3")) {
          // Enter '3' -- to view course listings by faculty and administrator
          final String sql = facultyCoursesWithProfitAndAdmin();
          final Statement stmt = con.createStatement();
          final ResultSet rs = stmt.executeQuery(sql);
          view.show("\nCourse List:");
          while (rs.next()) {
            System.out.format("%-5s", "********************************"
                + "\nInstructor : " + rs.getString("Professor")
                + "\n# of Courses: " + rs.getString("NumberOfCourses")
                + "\nTotal Course Revenue: $" + rs.getString("Earn")
                + "\nAccount Admin: " + rs.getString("Administrator") + "\n\n");
          }
        } else if (option.equals("4")) {
          // Enter '4' -- to view a user's account history
          final String sql = userAccountHistory();
          wrap(sql, FIXED_WIDTH);
          final PreparedStatement stmt = con.prepareStatement(sql);
          view.show("Enter student ID:");
          int stuid = 0;
          // show admin menu again if not enter an integer
          try {
            stuid = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Student ID should be a number.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // show admin menu again if student id is not valid
          if (!isValidStuId(con, stuid)) {
            view.show("Student ID is not valid.");
            view.printAdminMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          stmt.setInt(1, stuid);
          final ResultSet rs = stmt.executeQuery();
          view.show("\nAccount History:");
          while (rs.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourse: " + rs.getString("Course")
                + "\nInstructor: " + rs.getString("Instructor")
                + "\nEnrollment Date: " + rs.getString("EnrollDate")
                + "\nCompletion Date: " + (rs.getString("CompleteDate") == null ?
                "Not completed yet" : rs.getString("CompleteDate"))
                + "\nPrice: $" + rs.getString("Price")
                + "\nPayment Code: " + rs.getString("PaymentCode") + "\n\n");
          }
          final String spent = userTotalSpent();
          final PreparedStatement stmt2 = con.prepareStatement(spent);
          stmt2.setInt(1, stuid);
          final ResultSet rs2 = stmt2.executeQuery();
          rs2.next();
          final int amount = rs2.getInt("Total");
          view.show("This user spent $" + amount + " in total");
        }
        view.printAdminMenu();
        view.show("Enter your option:");
        option = scan.nextLine();
      } catch (SQLException e) {
        System.out.printf("Error connecting to db: %s%n", e.getMessage());
        System.exit(0);
      }
    }
    return option;
  }

  /**
   * Implement of the Faculty menu
   *
   * @param con current database connection
   * @param scan scanner of user input
   * @return a string that represents uesr's next option
   * @throws IOException when IO exceptions occurs
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static String runFacMenu(Connection con, Scanner scan) throws IOException,
      ClassNotFoundException, SQLException {
    // ask the user to enter faculty id
    view.show("Enter your Faculty ID: ");
    int facid = 0;
    // return to prev menu if not enter an integer
    try {
      facid = Integer.parseInt(scan.nextLine());
    } catch (NumberFormatException e) {
      view.show("Faculty ID should be a number.");
      return "p";
    }
    // return to prev menu if faculty id is not in the database
    if (!isValidFacId(con, facid)) {
      view.show("Invalid Faculty ID.");
      return "p";
    }
    view.printFacultyMenu();
    view.show("Enter your option:");
    String option = scan.nextLine();
    while (!option.equalsIgnoreCase("p") && !option.equalsIgnoreCase("q")) {
      try {
        if ((!(option.equals("1"))) && (!(option.equals("2"))) && (!(option.equals("3")))
            && (!(option.equalsIgnoreCase("p")))
            && (!(option.equalsIgnoreCase("q")))) {
          view.show("*************************************************\n"
              + "'" + option + "'" + " is not a valid menu option, please try again:\n"
              + "*************************************************");
        }
        if (option.equals("1")) {
          // Enter '1' -- to view your course questions and answers
          final String sql = printQuestions();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, facid);
          final ResultSet rs = stmt.executeQuery();
          view.show("\nCourse questions and answers:");
          while (rs.next()) {
            System.out
                .format("%-20s", "************************************************************"
                    + "\nTopic: " + rs.getString("Topic")
                    + "\nCourse: " + rs.getString("Course")
                    + "\nQuestion_Title: " + wrap((rs.getString("Title")), FIXED_WIDTH)
                    + ".\nQuestion: " + wrap((rs.getString("Question")), FIXED_WIDTH)
                    + ".\nAnswer: " + wrap((rs.getString("Answer")), FIXED_WIDTH)
                    + ".\nAsked By: " + wrap((rs.getString("Asker")), FIXED_WIDTH)
                    + "\n# of Likes: " + wrap((rs.getString("Likes")), FIXED_WIDTH) + "\n\n");
          }
        } else if (option.equals("2")) {
          // Enter '2' -- to search courses by email
          final String sql = facultyCourseByEmail();
          view.show("Enter faculty email:");
          final String email = scan.nextLine();
          // check if email is valid email address
          boolean isValid = EmailValidator.getInstance().isValid(email);
          if (!isValid) {
            view.show("********************************************\n'"
                + email + "' is not a valid email address\n"
                + "*******************************************");
          } else {
            final PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, email);
            final ResultSet rs = stmt.executeQuery();
            if (!rs.next()) {
              view.show("***********************\n"
                  + "Faculty email not found\n"
                  + "***********************");
            } else {
              rs.beforeFirst();
              view.show("\nCourses:");
              while (rs.next()) {
                System.out.format("%-5s", "********************"
                    + "\nCourse: " + rs.getString("Course")
                    + "\nCurrent Enrollment: " + rs.getString("num_enrolled") + "\n\n");
              }
            }
          }
        } else if (option.equals("3")) {
          // Enter '3' -- to view course listings by faculty and administrator
          final String sql = facultyCoursesWithProfitAndAdmin();
          final Statement stmt = con.createStatement();
          final ResultSet rs = stmt.executeQuery(sql);
          view.show("\nCouse List:");
          while (rs.next()) {
            System.out.format("%-5s", "*******************************"
                + "\nInstructor : " + rs.getString("Professor")
                + "\n# of Courses: " + rs.getString("NumberOfCourses")
                + "\nTotal Course Revenue: $" + rs.getString("Earn")
                + "\nAccount Admin: " + rs.getString("Administrator") + "\n\n");
          }

        }
        view.printFacultyMenu();
        option = scan.nextLine();
      } catch (SQLException e) {
        System.out.printf("Error connecting to db: %s%n", e.getMessage());
        System.exit(0);
      }
    }

    return option;
  }

  /**
   * Implement of the Student Menu
   *
   * @param con current database connection
   * @param scan scanner of user input
   * @return a string that represents uesr's next option
   * @throws IOException when IO exceptions occurs
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static String runStuMenu(Connection con, Scanner scan) throws IOException,
      ClassNotFoundException, SQLException {
    // ask the user to enter student id
    view.show("Enter your student ID:");
    int stuid = 0;
    // return to prev menu if not enter an integer
    try {
      stuid = Integer.parseInt(scan.nextLine());
    } catch (NumberFormatException e) {
      view.show("Student ID should be a number.");
      return "p";
    }
    // return to prev menu if student id is not in the database
    if (!isValidStuId(con, stuid)) {
      view.show("Invalid Student ID.");
      return "p";
    }
    view.printStudentMenu();
    view.show("Enter your option:");
    String option = scan.nextLine();
    while (!option.equalsIgnoreCase("p") && !option.equalsIgnoreCase("q")) {
      try {
        if ((!(option.equals("1"))) && (!(option.equals("2"))) && (!(option.equals("3")))
            && (!(option.equals("4"))) && (!(option.equals("5")))
            && (!(option.equals("6"))) && (!(option.equals("7")))
            && (!(option.equals("8"))) && (!(option.equals("9")))
            && (!(option.equalsIgnoreCase("p")))
            && (!(option.equalsIgnoreCase("q")))) {
          view.show("*************************************************\n"
              + "'" + option + "'" + " is not a valid menu option, please try again:\n"
              + "*************************************************");
        }
        if (option.equals("1")) {
          // Enter '1' -- to view your course history
          final String enrolled = enrolledCourses();
          final PreparedStatement stmt1 = con.prepareStatement(enrolled);
          stmt1.setInt(1, stuid);
          final ResultSet rs1 = stmt1.executeQuery();
          view.show("\nYou are enrolled in the following courses:");
          while (rs1.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourseId: " + rs1.getString("CourseId")
                + "\nCourse: " + rs1.getString("Name")
                + "\nPrimary Topic: " + rs1.getString("Primarytopic")
                + "\nSecondary Topic: " + rs1.getString("Secondarytopic")
                + "\nCourse Rating: " + rs1.getString("score") + "\n\n");
          }
          final String completed = completedCourses();
          final PreparedStatement stmt2 = con.prepareStatement(completed);
          stmt2.setInt(1, stuid);
          final ResultSet rs2 = stmt2.executeQuery();
          view.show("\nYou have completed the following courses:");
          while (rs2.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourseId: " + rs2.getString("CourseId")
                + "\nCourse: " + rs2.getString("Name")
                + "\nPrimary Topic: " + rs2.getString("Primarytopic")
                + "\nSecondary Topic: " + rs2.getString("Secondarytopic")
                + "\nCourse Rating: " + rs2.getString("score") + "\n\n");
          }
          final String interested = interestedCourses();
          final PreparedStatement stmt3 = con.prepareStatement(interested);
          stmt3.setInt(1, stuid);
          final ResultSet rs3 = stmt3.executeQuery();
          view.show("\nYou are interested in the following courses:");
          while (rs3.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourseId: " + rs3.getString("CourseId")
                + "\nCourse: " + rs3.getString("Name")
                + "\nPrimary Topic: " + rs3.getString("Primarytopic")
                + "\nSecondary Topic: " + rs3.getString("Secondarytopic")
                + "\nCourse Rating: " + rs3.getString("score") + "\n\n");
          }
        } else if (option.equals("2")) {
          // Enter '2' -- to search courses by keyword
          final String sql = courseKeywordSearch();
          view.show("Enter a keyword:");
          String keyword = scan.nextLine();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setString(1, keyword);
          final ResultSet rs = stmt.executeQuery();
          if (!rs.next()) {
            view.show("******************************************************\n"
                + "SEARCH RETURNED EMPTY, PLEASE TRY A DIFFERENT KEYWORD:\n"
                + "******************************************************");

          } else {
            view.show("\nA list of courses related to " + keyword + ":");
            rs.beforeFirst();
            while (rs.next()) {
              System.out.format("%-5s", "********************"
                  + "\nCourse: " + rs.getString("Name")
                  + "\nCourse Rating: " + rs.getString("Rating")
                  + "\nInstructor: " + rs.getString("Instructor")
                  + "\nTotal Course Materials: " + rs.getString("MaterialCount")
                  + "\nFiles: " + rs.getString("FileCount")
                  + "\nLinks: " + rs.getString("LinkCount")
                  + "\nPosts: " + rs.getString("PostCount") + "\n\n");
            }
          }
        } else if (option.equals("3")) {
          // Enter '3' -- to enroll in a course
          final String sql = enrollCourse();
          view.show("Enter course ID:");
          int courseid = 0;
          // print student menu again if not enter an integer
          try {
            courseid = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Course ID should be a number.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // print student menu again if course id is not valid
          if (!isValidCourseId(con, courseid)) {
            view.show("Course ID is not valid.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // print student menu again if this student has enrolled in this course
          if (checkCourseEnrollment(con, stuid, courseid)) {
            view.show("You have enrolled in this course.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          view.show("Enter your payment code:");
          final String code = scan.nextLine();
          view.show("Enter date in yyyy-mm-dd format:");
          final String date = scan.nextLine();
          view.show("Enter time in hh:mm:ss format:");
          final String time = scan.nextLine();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, stuid);
          stmt.setInt(2, courseid);
          stmt.setString(3, code);
          stmt.setString(4, date);
          stmt.setString(5, time);
          int num = stmt.executeUpdate();
          view.show("Enrolled in " + num + " course");
        } else if (option.equals("4")) {
          // Enter '4' -- to view materials for a course you are taking
          final String sql = materialStatus();
          view.show("Enter course ID:");
          int courseid = 0;
          // print student menu again if not enter an integer
          try {
            courseid = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Course ID should be a number.");
            option = "p";
            break;
          }
          // print student menu again if course id is not valid
          if (!isValidCourseId(con, courseid)) {
            view.show("Course ID is not valid.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // print student menu again if this student is not enrolled in this course
          if (!checkCourseEnrollment(con, stuid, courseid)) {
            view.show("You are not enrolled in this course.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, courseid);
          stmt.setInt(2, stuid);
          stmt.setInt(3, courseid);
          stmt.setInt(4, stuid);
          final ResultSet rs = stmt.executeQuery();
          while (rs.next()) {
            System.out.format("%-5s", "********************"
                + "\nOrder to be completed: " + rs.getString("OrderId")
                + "\nTitle: " + rs.getString("Name")
                + "\nCompletion Status: " + rs.getString("Status") + "\n\n");
          }
        } else if (option.equals("5")) {
          // Enter '5' -- to study a new materials for a course you are taking
          // step1: get next new material, if no new material, let the student know the course is completed
          final String sql1 = nextMaterial();
          view.show("Enter course ID:");
          int courseid = 0;
          // print student menu again if not enter an integer
          try {
            courseid = Integer.parseInt(scan.nextLine());
          } catch (NumberFormatException e) {
            view.show("Course ID should be a number.");
            option = "p";
            break;
          }
          // print student menu again if course id is not valid
          if (!isValidCourseId(con, courseid)) {
            view.show("Course ID is not valid.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          // print student menu again if this student is not enrolled in this course
          if (!checkCourseEnrollment(con, stuid, courseid)) {
            view.show("You are not enrolled in this course.");
            view.printStudentMenu();
            view.show("Enter your option:");
            option = scan.nextLine();
            continue;
          }
          final PreparedStatement stmt1 = con.prepareStatement(sql1);
          stmt1.setInt(1, courseid);
          stmt1.setInt(2, stuid);
          final ResultSet rs1 = stmt1.executeQuery();
          if (!rs1.first()) {
            view.show("You have finished all materials.");
            view.printStudentMenu();
            option = scan.nextLine();
            continue;
          }
          final int materialid = rs1.getInt("MaterialId");
          // step2: mark course material as completed
          System.out.println("in step 2");
          final String sql2 = completeMaterial();
          view.show("Enter date in yyyy-mm-dd format:");
          final String date = scan.nextLine();
          view.show("Enter time in hh:mm:ss format:");
          final String time = scan.nextLine();
          final PreparedStatement stmt2 = con.prepareStatement(sql2);
          stmt2.setInt(1, stuid);
          stmt2.setInt(2, materialid);
          stmt2.setString(3, date);
          stmt2.setString(4, time);
          final int num1 = stmt2.executeUpdate();
          view.show(num1 + " material has been marked completed.");
          // step3: if course is not completed, continue
          final String sql3 = checkCourseCompletion();
          final PreparedStatement stmt3 = con.prepareStatement(sql3);
          stmt3.setInt(1, courseid);
          stmt3.setInt(2, stuid);
          final ResultSet rs3 = stmt3.executeQuery();
          if (rs3.first()) {
            view.printStudentMenu();
            view.show("Enter your option: ");
            option = scan.nextLine();
            continue;
          }
          // step4: if course is completed, get information from student
          final String sql4 = markCourseCompletion();
          final PreparedStatement stmt4 = con.prepareStatement(sql4);
          view.show("You have finished this course!");
          view.show("Enter a rating:");
          String rating = scan.nextLine();
          view.show("Enter your comment:");
          String comment = scan.nextLine();
          stmt4.setString(1, rating);
          stmt4.setString(2, date);
          stmt4.setString(3, comment);
          stmt4.setInt(4, stuid);
          stmt4.setInt(5, courseid);
          stmt4.setInt(6, courseid);
          stmt4.setInt(7, stuid);
          int num = stmt4.executeUpdate();
          view.show(num + " course has been marked completed.");
        } else if (option.equals("6")) {
          // Enter '6' -- to view course materials from the most popular course
          final String sql = popularCourseMaterials();
          view.show("Enter a keyword:");
          String keyword = scan.nextLine();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setString(1, keyword);
          stmt.setString(2, keyword);
          stmt.setString(3, keyword);
          stmt.setString(4, keyword);
          stmt.setString(5, keyword);
          stmt.setString(6, keyword);
          final ResultSet rs = stmt.executeQuery();
          if (!rs.next()) {
            view.show("******************************************************\n"
                + "SEARCH RETURNED EMPTY, PLEASE TRY A DIFFERENT KEYWORD:\n"
                + "******************************************************");

          } else {
            view.show("\nCourse materials from the most popular course:");
            rs.beforeFirst();
            while (rs.next()) {
              System.out.format("%-5s", "********************"
                  + "\nCourseID: " + rs.getString("CourseId")
                  + "\nCourse: " + rs.getString("CourseName")
                  + "\nMaterial Type: " + rs.getString("Type")
                  + "\nMaterial Description:\n"
                  + wrap((rs.getString("Description")), FIXED_WIDTH) + "\n\n");
            }
          }
        } else if (option.equals("7")) {
          // Enter '7' -- to view all course listings
          final String sql = courseListings();
          final Statement stmt = con.createStatement();
          final ResultSet rs = stmt.executeQuery(sql);
          view.show("\nCourse List:");
          while (rs.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourseId: " + rs.getString("CourseId")
                + "\nCourse: " + rs.getString("Course")
                + "\nInstructor: " + rs.getString("Professor")
                + "\nPrimary Topic: " + rs.getString("PrimaryTopic")
                + "\nCurrent Enrollment: " + rs.getString("CurrentEnrollment")
                + "\nCurrent Interest: " + rs.getString("Interested") + "\n\n");
          }
        } else if (option.equals("8")) {
          // Enter '8' -- to view your account history
          final String sql = userAccountHistory();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, stuid);
          final ResultSet rs = stmt.executeQuery();
          view.show("\nYour account history:");
          while (rs.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourse: " + rs.getString("Course")
                + "\nInstructor: " + rs.getString("Instructor")
                + "\nEnrollment Date: " + rs.getString("EnrollDate")
                + "\nCompletion Date: " + rs.getString("CompleteDate")
                + "\nTuition Cost: $" + rs.getString("Price")
                + "\nPayment Code: " + rs.getString("PaymentCode") + " " + "\n\n");
          }
          final String spent = userTotalSpent();
          final PreparedStatement stmt2 = con.prepareStatement(spent);
          stmt2.setInt(1, stuid);
          final ResultSet rs2 = stmt2.executeQuery();
          rs2.next();
          final int amount = rs2.getInt("Total");
          view.show("You spent $" + amount + " in total");
        } else if (option.equals("9")) {
          // Enter '9' -- to view your course certifications
          final String sql = viewCertifications();
          final PreparedStatement stmt = con.prepareStatement(sql);
          stmt.setInt(1, stuid);
          final ResultSet rs = stmt.executeQuery();
          view.show("\nCourse certifications:");
          while (rs.next()) {
            System.out.format("%-5s", "********************"
                + "\nCourse: " + rs.getString("CourseName")
                + "\nCertifying Instructor: " + rs.getString("FirstName")
                + " " + rs.getString("LastName")
                + "\nDate of Completion: " + rs.getString("CompleteDate")
                + "\nTime of Completion: " + rs.getString("CompleteTime") + "\n\n");
          }
        }
        view.printStudentMenu();
        view.show("Enter your option: ");
        option = scan.nextLine();
      } catch (SQLException e) {
        System.out.printf("Error connecting to db: %s%n", e.getMessage());
        System.exit(0);
      }
    }

    return option;
  }

  /**
   * check if the administrator id is in database
   *
   * @param con current database connection
   * @param id admin id
   * @return true if the admin id exists in database, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isValidAdminId(Connection con, int id) throws SQLException {
    final String query = "SELECT * FROM Administrator WHERE AdminId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, id);
    final ResultSet rs = stmt.executeQuery();
    return rs.first();
  }

  /**
   * check if the faculty id is in database
   *
   * @param con current database connection
   * @param id faculty id
   * @return true if the faculty id exists in database, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isValidFacId(Connection con, int id) throws SQLException {
    final String query = "SELECT * FROM Faculty WHERE FacultyId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, id);
    final ResultSet rs = stmt.executeQuery();
    return rs.first();
  }

  /**
   * check if the student id is in database
   *
   * @param con current database connection
   * @param id student id
   * @return true if the student id exists in database, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isValidStuId(Connection con, int id) throws SQLException {
    final String query = "SELECT * FROM Student WHERE StuId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, id);
    final ResultSet rs = stmt.executeQuery();
    return rs.first();
  }

  /**
   * check if the course id is in database
   *
   * @param con current database connection
   * @param id course id
   * @return true if the course id exists in database, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isValidCourseId(Connection con, int id) throws SQLException {
    final String query = "SELECT * FROM Course WHERE CourseId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, id);
    final ResultSet rs = stmt.executeQuery();
    return rs.first();
  }

  /**
   * check if the faculty has been verified or not
   *
   * @param con current database connection
   * @param facid faculty id
   * @return true if the faculty has been verified, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isVerifiedFac(Connection con, int facid) throws SQLException {
    final String query = "SELECT VerifiedBy FROM Faculty WHERE FacultyId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, facid);
    final ResultSet rs = stmt.executeQuery();
    rs.next();
    if (rs.getString("VerifiedBy") == null) {
      return false;
    }
    return true;
  }

  /**
   * check if the admin has been verified or not
   *
   * @param con current database connection
   * @param adminid admin id
   * @return true if the admin has been verified, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean isVerifiedAdmin(Connection con, int adminid) throws SQLException {
    final String query = "SELECT Grantor FROM Administrator WHERE AdminId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, adminid);
    final ResultSet rs = stmt.executeQuery();
    rs.next();
    if (rs.getString("Grantor") == null) {
      return false;
    }
    return true;
  }

  /**
   * check if the student has enrolled in the course or not
   *
   * @param con current database connection
   * @param stuid current student
   * @param courseid current course
   * @return true if the student has enrolled in this course, false otherwise
   * @throws SQLException when exception occurs when trying to run sql query
   */
  private static boolean checkCourseEnrollment(Connection con, int stuid, int courseid) throws SQLException {
    final String query = "SELECT * FROM CourseEnrollment WHERE StuId=? AND CourseId=?;";
    final PreparedStatement stmt = con.prepareStatement(query);
    stmt.setInt(1, stuid);
    stmt.setInt(2, courseid);
    final ResultSet rs = stmt.executeQuery();
    return rs.first();
  }

  // The following methods are to get the corresponding queries for each operation //

  /**
   * Faculty: Enter '1' -- to view all course questions and answers
   *
   * @return this SQL query
   */
  private static String printQuestions() {
    return ""
        + "SELECT q1.Topic AS Topic, q1.course_name AS Course, q1.Title AS Title, q1.question AS Question, "
        + "q1.answer AS Answer, q1.Asker AS Asker, q1.Likes AS Likes "
        + "FROM(SELECT q.QuestionId AS Id, t.Name AS Topic, c.Name AS course_name, "
        + "q.Title AS Title, q.Content AS question, fu.Answer AS answer, "
        + "CONCAT(u.FirstName,' ',u.LastName) AS Asker, COUNT(lq.StuId) AS Likes "
        + "FROM Question q INNER JOIN Student s ON q.StuId=s.StuId "
        + "INNER JOIN User u ON s.UserId=u.UserId "
        + "LEFT JOIN QuestionRelateTo qrt ON q.QuestionId=qrt.QuestionId "
        + "INNER JOIN CourseMaterial cm ON qrt.MaterialId=cm.MaterialId "
        + "INNER JOIN Course c ON cm.CourseId=c.CourseId "
        + "INNER JOIN Topic t ON c.TopicId=t.TopicId "
        + "INNER JOIN CourseCreation cc ON c.CourseId=cc.CourseId "
        + "LEFT JOIN FindUseful fu ON q.QuestionId=fu.QuestionId "
        + "LEFT JOIN LikeQuestion lq ON q.QuestionId=lq.QuestionId "
        + "WHERE cc.FacultyId=? "
        + "GROUP BY Id) q1 "
        + "ORDER BY Likes DESC, Topic ASC, Course ASC;";
  }

  /**
   * Faculty: Enter '2' -- to search courses by email
   *
   * @return this SQL query
   */
  private static String facultyCourseByEmail() {
    return ""
        + "SELECT c.Name AS Course, COUNT(en.StuId) AS num_enrolled "
        + "FROM (((User u INNER JOIN Faculty fac ON u.UserId=fac.UserId "
        + "INNER JOIN CourseCreation cc ON fac.FacultyId=cc.FacultyId) "
        + "INNER JOIN Course c ON cc.CourseId=c.CourseId) "
        + "LEFT JOIN CourseEnrollment en ON c.CourseId=en.CourseId) WHERE u.Email LIKE ? "
        + "GROUP BY Course "
        + "ORDER BY num_enrolled DESC, Course ASC;";
  }

  /**
   * Faculty: Enter '3' -- to view course listings by faculty
   * Admin: Enter '3' -- to view course listings by faculty
   *
   * @return this SQL query
   */
  private static String facultyCoursesWithProfitAndAdmin() {
    return ""
        + "SELECT q4.Professor AS Professor, q4.NumberOfCourses "
        + "AS NumberOfCourses, q4.Earn AS Earn, CONCAT(u.FirstName,' ',u.LastName) AS Administrator "
        + "FROM Faculty f LEFT JOIN (SELECT CONCAT(u.FirstName,' ',u.LastName) AS Professor, "
        + "f.FacultyId AS FacultyId, q3.NumberOfCourses AS NumberOfCourses,q2.Earn AS Earn "
        + "FROM Faculty f INNER JOIN User u ON f.UserId=u.UserId "
        + "INNER JOIN(SELECT f.FacultyId AS FacultyId, COUNT(cc.CourseId) AS NumberOfCourses "
        + "FROM Faculty f Left JOIN CourseCreation cc ON f.FacultyId=cc.FacultyId "
        + "GROUP BY FacultyId)q3 ON f.FacultyId=q3.FacultyId LEFT JOIN "
        + "(SELECT q1.FacultyId AS FacultyId, SUM(q1.Cost) AS Earn "
        + "FROM (SELECT f.FacultyId AS FacultyId, cc.CourseId AS CourseId, c.Cost AS Cost, ce.StuId AS StuId "
        + "FROM Faculty f INNER JOIN CourseCreation cc ON f.FacultyId=cc.FacultyId "
        + "INNER JOIN Course c ON cc.CourseId=c.CourseId "
        + "INNER JOIN CourseEnrollment ce ON c.CourseId=ce.CourseId)q1 "
        + "GROUP BY FacultyId)q2 ON q3.FacultyId=q2.FacultyId) q4 ON f.FacultyId=q4.FacultyId "
        + "INNER JOIN Administrator a ON f.VerifiedBy=a.AdminId INNER JOIN User u ON a.UserId=u.UserId "
        + "ORDER BY Earn DESC, NumberOfCourses DESC, Professor ASC;";
  }

  /**
   * Student: Enter '1' -- to view your course history with currently  enrolled courses
   *
   * @return this SQL query
   */
  private static String enrolledCourses() {
    return ""
        + "SELECT q1.CourseId AS CourseId, q1.Name, q1.Primarytopic, top.Name AS Secondarytopic, q1.rate As score "
        + "FROM (SecondaryTopics st INNER JOIN Topic top ON st.TopicId=top.TopicId) "
        + "RIGHT JOIN (SELECT c.CourseId As CourseId, c.Name As Name, c.AvgRating As rate,t.Name As Primarytopic "
        + "From (Course c INNER JOIN CourseEnrollment ce ON c.CourseId=ce.CourseId) "
        + "INNER JOIN Topic t ON c.TopicId=t.TopicId "
        + "WHERE ce.StuId=? and ce.Certification=0)q1 ON q1.CourseId=st.CourseId "
        + "ORDER BY score DESC, CourseId;";
  }

  /**
   * Student: Enter '1' -- to view your course history with completed course
   *
   * @return this SQL query
   */
  private static String completedCourses() {
    return ""
        + "SELECT q1.CourseId AS CourseId, q1.Name, q1.Primarytopic, top.Name AS Secondarytopic, q1.rate As score "
        + "FROM (SecondaryTopics st INNER JOIN Topic top ON st.TopicId=top.TopicId) "
        + "Right JOIN (SELECT c.CourseId As CourseId, c.Name As Name, c.AvgRating As rate,t.Name As Primarytopic "
        + "From (Course c INNER JOIN CourseEnrollment ce ON c.CourseId=ce.CourseId) "
        + "INNER JOIN Topic t ON c.TopicId=t.TopicId "
        + "WHERE ce.StuId=? and ce.Certification=1)q1 ON q1.CourseId=st.CourseId "
        + "ORDER BY score DESC, CourseId;";
  }

  /**
   * Student: Enter '1' -- to view your course history and interested courses
   *
   * @return this SQL query
   */
  private static String interestedCourses() {
    return ""
        + "SELECT q1.CourseId AS CourseId, q1.Name, q1.Primarytopic, top.Name AS Secondarytopic, q1.rate As score "
        + "FROM (SecondaryTopics st INNER JOIN Topic top ON st.TopicId=top.TopicId) "
        + "RIGHT JOIN (SELECT c.CourseId As CourseId, c.Name As Name, c.AvgRating As rate,t.Name As Primarytopic "
        + "From (Course c INNER JOIN CourseInterest ci ON c.CourseId=ci.CourseId) "
        + "INNER JOIN Topic t ON c.TopicId=t.TopicId "
        + "WHERE ci.StuId=?)q1 ON q1.CourseId=st.CourseId "
        + "Order BY CourseId, score DESC;";
  }

  /**
   * Student: Enter '2' -- to search courses by keyword
   *
   * @return this SQL query
   */
  private static String courseKeywordSearch() {
    return ""
        + "SELECT Course.Name AS Name, CONCAT(u.FirstName,' ',u.LastName) AS Instructor, COUNT(*) AS MaterialCount, "
        + "(SELECT COUNT(*) FROM CourseMaterial INNER JOIN DownloadableFile "
        + "ON CourseMaterial.MaterialId=DownloadableFile.MaterialId "
        + "WHERE CourseMaterial.CourseId=Course.CourseId) AS FileCount, "
        + "(SELECT COUNT(*) FROM CourseMaterial INNER JOIN Link ON CourseMaterial.MaterialId=Link.MaterialId "
        + "WHERE CourseMaterial.CourseId=Course.CourseId) AS LinkCount, "
        + "(SELECT COUNT(*) FROM CourseMaterial INNER JOIN Post ON CourseMaterial.MaterialId=Post.MaterialId "
        + "WHERE CourseMaterial.CourseId=Course.CourseId) AS PostCount, "
        + "Course.AvgRating AS Rating "
        + "FROM Course INNER JOIN CourseMaterial ON Course.CourseId=CourseMaterial.CourseId "
        + "INNER JOIN CourseCreation cc ON Course.CourseId=cc.CourseId "
        + "INNER JOIN Faculty f ON cc.FacultyId=f.FacultyId "
        + "INNER JOIN User u ON f.UserId=u.UserId "
        + "WHERE Course.Name Like Concat('%',?,'%') "
        + "GROUP BY Course.CourseId "
        + "ORDER BY MaterialCount DESC, Name ASC;";
  }

  /**
   * Student: Enter '3' -- to enroll in a course
   *
   * @return this SQL query
   */
  private static String enrollCourse() {
    return ""
        + "INSERT INTO CourseEnrollment (StuId, CourseId, Code, Date, "
        + "Time, Rating, Certification, CompleteDate, Comment) "
        + "VALUES(?, ?, ?, ?, ?, NULL, 0, NULL, NULL);";
  }

  /**
   * Student: Enter '4' -- to view materials for a course you are taking
   *
   * @return this SQL query
   */
  private static String materialStatus() {
    return ""
        + "SELECT OrderId, Name, 'Completed' AS Status "
        + "FROM CourseMaterial "
        + "WHERE CourseId=? AND MaterialId IN "
        + "(SELECT MaterialId "
        + "FROM MaterialCompletion "
        + "WHERE StuId=?) "
        + "UNION "
        + "SELECT OrderId, Name, 'Not Completed' AS Status "
        + "FROM CourseMaterial "
        + "WHERE CourseId=? AND MaterialId NOT IN "
        + "(SELECT MaterialId "
        + "FROM MaterialCompletion "
        + "WHERE StuId=?);";
  }

  /**
   * Student: Enter '5' -- to study a new materials for a course you are taking
   *
   * @return this SQL query
   */
  private static String nextMaterial() {
    return ""
        + "SELECT MaterialId "
        + "FROM CourseMaterial "
        + "WHERE CourseId=? AND MaterialId NOT IN "
        + "(SELECT MaterialId "
        + "FROM MaterialCompletion "
        + "WHERE StuId=?) "
        + "ORDER BY OrderId "
        + "LIMIT 1;";
  }

  /**
   * 2nd query for Student: Enter '5' -- to study a new materials for a course you are taking
   *
   * @return this SQL query
   */
  private static String completeMaterial() {
    return ""
        + "INSERT INTO `MaterialCompletion` (`StuId`, `MaterialId`, `Date`, `Time`) VALUES "
        + "(?, ?, ?, ?);";
  }

  /**
   * 3rd query for Student: Enter '5' -- to study a new materials for a course you are taking
   *
   * @return this SQL query
   */
  private static String checkCourseCompletion() {
    return ""
        + "SELECT MaterialId "
        + "FROM CourseMaterial "
        + "WHERE CourseId=? AND MaterialId NOT IN "
        + "(SELECT MaterialId "
        + "FROM MaterialCompletion "
        + "WHERE StuId=?) "
        + "ORDER BY OrderId "
        + "LIMIT 1;";
  }

  /**
   * 4th query for Student: Enter '5' -- to study a new materials for a course you are taking
   *
   * @return this SQL query
   */
  private static String markCourseCompletion() {
    return ""
        + "UPDATE CourseEnrollment "
        + "SET Rating=?, Certification=1, CompleteDate=?, Comment=? "
        + "WHERE StuId=? "
        + "AND CourseId=? "
        + "AND Certification=0 "
        + "AND NOT EXISTS (SELECT * FROM CourseMaterial "
        + "WHERE CourseId=? AND MaterialId NOT IN "
        + "(SELECT MaterialId "
        + "FROM MaterialCompletion "
        + "WHERE StuId=?));";
  }

  /**
   * Student: Enter '6' -- to view course materials from the most popular course
   *
   * @return this SQL query
   */
  private static String popularCourseMaterials() {
      return "SELECT c.CourseId AS CourseId, c.Name AS CourseName,'Downloadable File' AS Type, "
          + "df.Path AS Description "
          + "FROM CourseMaterial cm INNER JOIN DownloadableFile df ON df.MaterialId=cm.MaterialId INNER JOIN Course c "
          + "ON c.CourseId=cm.CourseId "
          + "WHERE cm.CourseId = (SELECT q1.CourseId "
          + "FROM (SELECT COUNT(ce.StuId) AS number, ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name like Concat('%',?,'%') "
          + "GROUP BY CourseId) q1 "
          + "WHERE q1.number = (SELECT MAX(q1.number) FROM "
          + "(SELECT COUNT(ce.StuId) AS number, ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name Like Concat('%',?,'%') "
          + "GROUP BY CourseId) q1)) "
          + "UNION ALL "
          + "SELECT c.CourseId AS CourseId, c.Name AS CourseName,'Link' AS Type, l.URL AS Description "
          + "FROM CourseMaterial cm INNER JOIN Link l ON l.MaterialId=cm.MaterialId INNER JOIN Course c "
          + "ON c.CourseId=cm.CourseId "
          + "WHERE cm.CourseId = (SELECT q1.CourseId "
          + "FROM (SELECT COUNT(ce.StuId) AS number, ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name like Concat('%',?,'%') "
          + "GROUP BY CourseId) q1 "
          + "WHERE q1.number = (SELECT MAX(q1.number) FROM "
          + "(SELECT COUNT(ce.StuId) AS number, ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name like Concat('%',?,'%') "
          + "GROUP BY CourseId) q1)) "
          + "UNION ALL "
          + "SELECT c.CourseId AS CourseId, c.Name AS CourseName,'Post' AS Type, p.Text AS Description "
          + "FROM CourseMaterial cm INNER JOIN Post p ON p.MaterialId=cm.MaterialId INNER JOIN Course c "
          + "ON c.CourseId=cm.CourseId "
          + "WHERE cm.CourseId=(SELECT q1.CourseId "
          + "FROM (SELECT COUNT(ce.StuId) AS number,ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name like Concat('%',?,'%') "
          + "GROUP BY CourseId)q1 "
          + "WHERE q1.number=(SELECT MAX(q1.number) FROM "
          + "(SELECT COUNT(ce.StuId) AS number,ce.CourseId AS CourseId "
          + "FROM CourseEnrollment ce INNER JOIN Course c ON c.CourseId=ce.CourseId "
          + "WHERE c.Name like Concat('%',?,'%') "
          + "GROUP BY CourseId)q1)) "
          + "ORDER BY Type ASC, Description ASC;";
    }

  /**
   * Student: Enter '7' -- to view all course listings
   *
   * @return this SQL query
   */
  private static String courseListings() {
    return ""
        + "SELECT c.CourseId AS CourseId, c.Name AS Course, t.Name AS PrimaryTopic, CONCAT(u.FirstName,' ',u.LastName) "
        + "AS Professor, q1.NumberOfStudents AS CurrentEnrollment, q2.InterestStudents AS Interested "
        + "FROM Course c LEFT JOIN "
        + "(SELECT ce.CourseId AS CourseId, COUNT(ce.StuId) AS NumberOfStudents "
        + "FROM CourseEnrollment ce "
        + "GROUP BY CourseId) q1 ON c.CourseId=q1.CourseId "
        + "LEFT JOIN (SELECT ci.CourseId AS CourseId, COUNT(ci.StuId) AS InterestStudents "
        + "FROM CourseInterest ci "
        + "GROUP BY CourseId) q2 ON c.CourseId=q2.CourseId "
        + "INNER JOIN CourseCreation cc On cc.CourseId=c.CourseId "
        + "INNER JOIN Faculty f ON cc.FacultyId=f.FacultyId "
        + "INNER JOIN User u ON f.UserId=u.UserId "
        + "INNER JOIN Topic t ON c.TopicId=t.TopicId "
        + "ORDER BY CurrentEnrollment DESC, Interested DESC, PrimaryTopic ASC, Course ASC, Professor ASC;";
  }

  /**
   * Student: Enter '8' -- to view your account history
   * Admin: Enter '4' -- to view a user's account history
   *
   * @return this SQL query
   */
  private static String userAccountHistory() {
    return ""
        + "SELECT c.Name AS Course, CONCAT(u.FirstName,' ',u.LastName) AS Instructor,ce.Date AS EnrollDate, "
        + "ce.CompleteDate AS CompleteDate, c.Cost AS Price, ce.Code AS PaymentCode "
        + "FROM CourseEnrollment ce INNER JOIN Course c ON ce.CourseId=c.CourseId "
        + "INNER JOIN CourseCreation cc ON c.CourseId=cc.CourseId "
        + "INNER JOIN Faculty f ON f.FacultyId=cc.FacultyId "
        + "INNER JOIN User u ON u.UserId=f.UserId "
        + "WHERE ce.StuId=?;";
  }

  /**
   * Student: Enter '8' -- to view your account history and total spent
   *
   * @return this SQL query
   */
  private static String userTotalSpent() {
    return ""
        + "SELECT SUM(Course.Cost) AS Total "
        + "FROM CourseEnrollment INNER JOIN Course ON CourseEnrollment.CourseId=Course.CourseId "
        + "WHERE CourseEnrollment.StuId=?;";
  }

  /**
   * Student: Enter '9' -- to view your course certifications
   *
   * @return this SQL query
   */
  private static String viewCertifications() {
    return ""
        + "SELECT u.FirstName AS FirstName, u.LastName AS LastName, c.Name AS CourseName, "
        + "mc.Date AS CompleteDate, mc.Time AS CompleteTime "
        + "FROM (((User u INNER JOIN Student st ON u.UserId=st.UserId) INNER JOIN "
        + "(SELECT q2.StuId AS StuId, q2.CourseId AS CourseId, cml.MaterialId AS MaterialId "
        + "FROM CourseMaterial cml INNER JOIN "
        + "(SELECT q1.StuId AS StuId, q1.CourseId AS CourseId, MAX(cm.OrderId) AS OrderId "
        + "FROM CourseMaterial cm INNER JOIN "
        + "(SELECT ce.StuId AS StuId, ce.CourseId AS CourseId "
        + "FROM CourseEnrollment ce "
        + "WHERE StuId=? and ce.Certification=1)q1 ON cm.CourseId=q1.CourseId "
        + "Group by CourseId)q2 "
        + "ON (cml.OrderId = q2.OrderId and cml.CourseId=q2.CourseId))q3 ON st.StuId=q3.StuId) "
        + "INNER JOIN Course c ON q3.CourseId=c.CourseId) "
        + "INNER JOIN MaterialCompletion mc ON (q3.MaterialId=mc.MaterialId and q3.StuId=mc.StuId);";
  }

  /**
   * Admin: Enter '1' -- to authenticate a faculty user
   *
   * @return this SQL query
   */
  private static String authenticateFacultyUser() {
    return ""
        + "UPDATE Faculty SET VerifiedBy=?, Date=?, Time=? WHERE FacultyId=?;";
  }

  /**
   * Admin: Enter '2' -- to authenticate a fellow administrator
   *
   * @return this SQL query
   */
  private static String authenticateFellowAdmin() {
    return ""
        + "UPDATE Administrator SET Grantor=?, Date=?, Time=? WHERE Administrator.AdminId=?;";
  }
}


