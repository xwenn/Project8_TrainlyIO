/**
 * @author danscheirer
 */
package view.trainly;

import java.io.IOException;

/**
 * This class represents the graphical View that the user will see. This is the
 * user-side view of Trainly.io.
 */
public class View {

	final Appendable out;

	public View(Appendable out) {
		this.out = out;
	}

  /**
   * This method outputs the main program menu to the user, providing them with
   * the options to choose from and informing them how to quit the program.
   *
   * @throws IOException if there is an error displaying output or if the output is invalid.
   */
  public void printMainMenu() throws IOException {
    try {
      this.out.append("\nTrainly.io Main Menu: \n");
      this.out.append("1. -- Enter '1' -- to view the Student Menu.\n");
      this.out.append("2. -- Enter '2' -- to view the Faculty Menu.\n");
      this.out.append("3. -- Enter '3' -- to view the Administrator Menu.\n");
      this.out.append("4. -- Enter '4' -- to register as a new user.\n");
      this.out.append("5. -- Enter 'q' -- to quit the program.\n\n");
    } catch (IOException e) {
      System.out.println(e.toString());
      throw new IOException("Error printing menu:");
    }
  }

  /**
   * This method outputs the program menu for Students, providing them with
   * the options to choose from and informing them how to quit the program or return to the
   * previous screen.
   *
   * @throws IOException if there is an error displaying output or if the output is invalid.
   */
  public void printStudentMenu() throws IOException {
    try {
      this.out.append("\nTrainly.io Student Menu: \n");
      this.out.append("1. -- Enter '1' -- to view your course history.\n");
      this.out.append("2. -- Enter '2' -- to search courses by keyword.\n");
      this.out.append("3. -- Enter '3' -- to enroll in a course.\n");
      this.out.append("4. -- Enter '4' -- to view materials for a course you are taking.\n");
      this.out.append("5. -- Enter '5' -- to complete the next material for a course you are taking.\n");
      this.out.append("6. -- Enter '6' -- to view course materials from the most popular course.\n");
      this.out.append("7. -- Enter '7' -- to view all course listings\n");
      this.out.append("8. -- Enter '8' -- to view your account history.\n");
      this.out.append("9. -- Enter '9' -- to view your course certifications.\n");
      this.out.append("10. -- Enter 'p' -- to return to main menu\n");
      this.out.append("11. -- Enter 'q' -- to quit the program.\n\n");
    } catch (IOException e) {
      System.out.println(e.toString());
      throw new IOException("Error printing menu:");
    }
  }

  /**
   * This method outputs the program menu for Faculty, providing them with
   * the options to choose from and informing them how to quit the program or return to the
   * previous screen.
   *
   * @throws IOException if there is an error displaying output or if the output is invalid.
   */
  public void printFacultyMenu() throws IOException {
    try {
      this.out.append("\nTrainly.io Faculty Menu: \n");
      this.out.append("1. -- Enter '1' -- to view your course questions and answers.\n");
      this.out.append("2. -- Enter '2' -- to search courses by email.\n");
      this.out.append("3. -- Enter '3' -- to view course listings by faculty and administrator.\n");
      this.out.append("4. -- Enter 'p' -- to return to main menu\n");
      this.out.append("5. -- Enter 'q' -- to quit the program.\n\n");
    } catch (IOException e) {
      System.out.println(e.toString());
      throw new IOException("Error printing menu:");
    }
  }

  /**
   * This method outputs the program menu for Database Administrators, providing them with
   * the options to choose from and informing them how to quit the program or return to the
   * previous screen.
   *
   * @throws IOException if there is an error displaying output or if the output is invalid.
   */
  public void printAdminMenu() throws IOException {
    try {
      this.out.append("\nTrainly.io Database Administrator Menu: \n");
      this.out.append("1. -- Enter '1' -- to authenticate a faculty user.\n");
      this.out.append("2. -- Enter '2' -- to authenticate a fellow administrator.\n");
      this.out.append("3. -- Enter '3' -- to view course listings by faculty and administrator.\n");
      this.out.append("4. -- Enter '4' -- to view a user's account history.\n");
      this.out.append("5. -- Enter 'p' -- to return to previous menu\n");
      this.out.append("6. -- Enter 'q' -- to quit the program.\n\n");
    } catch (IOException e) {
      System.out.println(e.toString());
      throw new IOException("Error printing menu:");
    }
  }

  /**
   * Alerts the user that they have selected to quit the program, after which the
   * controller will end the program.
   *
   * @throws IOException if there is an error displaying output or if the output is invalid.
   */
  public void quitProgram() throws IOException {
    try {
      this.out.append("You have quit the program. Goodbye!\n");
    } catch (IOException e) {
      System.out.println(e.toString());
      throw new IOException("Error printing menu:");
    }
    System.exit(0);
  }

  /**
   * Print this String followed by a new line.
   * @param s this String
   */
  public void show(String s) {
    System.out.printf("%s\n", s);
  }

}
